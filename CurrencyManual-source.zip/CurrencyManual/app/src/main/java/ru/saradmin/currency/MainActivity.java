package ru.saradmin.currency;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    static class Cur {
        String code, name, flag, country; double rate;
        Cur(String c,String n,String f,String country,double r){code=c;name=n;flag=f;this.country=country;rate=r;}
    }
    ArrayList<Cur> currencies = new ArrayList<>();
    String base = "USD";
    EditText amount;
    LinearLayout root, results;
    int green = Color.rgb(8,122,67), dark=Color.rgb(25,30,28), muted=Color.rgb(100,106,103);
    DecimalFormat fmt = new DecimalFormat("#,##0.####");

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(247,248,247)); getWindow().setNavigationBarColor(Color.rgb(247,248,247)); load(); showMain(); }
    void load(){
        currencies.clear();
        android.content.SharedPreferences p=getSharedPreferences("rates",0);
        base=p.getString("base","USD"); String data=p.getString("list",null);
        if(data!=null) try { JSONArray a=new JSONArray(data); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i); currencies.add(new Cur(o.getString("c"),o.getString("n"),o.getString("f"),o.getString("country"),o.optDouble("r",0)));} }catch(Exception ignored){}
        if(currencies.isEmpty()){
            currencies.add(new Cur("USD","Доллар США","🇺🇸","us",1));
            currencies.add(new Cur("EUR","Евро","🇪🇺","eu",0.925));
            currencies.add(new Cur("KZT","Казахстанский тенге","🇰🇿","kz",492));
            currencies.add(new Cur("RUB","Российский рубль","🇷🇺","ru",91.5)); save();
        }
        if(find(base)==null) base=currencies.get(0).code;
    }
    Cur find(String c){for(Cur x:currencies)if(x.code.equals(c))return x;return null;}
    void save(){try{JSONArray a=new JSONArray();for(Cur c:currencies){JSONObject o=new JSONObject();o.put("c",c.code);o.put("n",c.name);o.put("f",c.flag);o.put("country",c.country);o.put("r",c.rate);a.put(o);}getSharedPreferences("rates",0).edit().putString("base",base).putString("list",a.toString()).apply();}catch(Exception ignored){}}
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(dark);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    GradientDrawable bg(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    void showMain(){
        root=col();root.setBackgroundColor(Color.rgb(247,248,247));pad(root,20,16,20,16);setContentView(root);
        LinearLayout header=row();TextView title=text("Конвертер",26,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button settings=button("⚙",false);header.addView(settings);settings.setOnClickListener(v->showSettings());root.addView(header);
        LinearLayout box=row();box.setBackground(bg(Color.WHITE,0xffd4d9d6));pad(box,16,12,12,12);LinearLayout left=col();TextView label=text("Сумма",14,false);label.setTextColor(muted);left.addView(label);amount=new EditText(this);amount.setSingleLine(true);amount.setTextSize(30);amount.setText("100");amount.setInputType(8194);amount.setPadding(0,0,0,0);amount.setBackgroundColor(Color.TRANSPARENT);left.addView(amount);box.addView(left,new LinearLayout.LayoutParams(0,-2,1));Button baseBtn=button(flag(base)+"  "+base+" ▾",true);box.addView(baseBtn);baseBtn.setOnClickListener(v->chooseBase());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(22);root.addView(box,bp);
        TextView hint=text("Курсы заданы вручную",14,false);hint.setTextColor(muted);hint.setGravity(Gravity.CENTER);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(14);root.addView(hint,hp);
        results=col();LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-1);rp.topMargin=dp(18);root.addView(results,rp);amount.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refreshResults();}public void afterTextChanged(android.text.Editable e){}});refreshResults();
    }
    String flag(String code){Cur c=find(code);return c==null?"🏳️":c.flag;}
    View flagView(String country,String fallback){
        File f=new File(getFilesDir(),"flag-"+country+".svg");
        if(f.exists()) { android.webkit.WebView w=new android.webkit.WebView(this); w.setBackgroundColor(Color.TRANSPARENT); w.setVerticalScrollBarEnabled(false); w.setHorizontalScrollBarEnabled(false); w.getSettings().setJavaScriptEnabled(false); w.getSettings().setAllowFileAccess(true); w.loadUrl("file://"+f.getAbsolutePath()); w.setLayoutParams(new LinearLayout.LayoutParams(dp(42),dp(30))); return w; }
        return text(fallback,26,false);
    }
    void refreshResults(){if(results==null)return;results.removeAllViews();double val=0;try{val=Double.parseDouble(amount.getText().toString().replace(',','.'));}catch(Exception ignored){}for(Cur c:currencies){if(c.code.equals(base))continue;LinearLayout card=row();card.setBackground(bg(Color.WHITE,0xffe3e7e4));pad(card,14,14,14,14);View f=flagView(c.country,c.flag);card.addView(f);LinearLayout names=col();TextView code=text(c.code,18,true);TextView rate=text("1 "+base+" = "+fmt.format(c.rate)+" "+c.code,12,false);rate.setTextColor(muted);names.addView(code);names.addView(rate);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);np.leftMargin=dp(14);card.addView(names,np);TextView out=text(fmt.format(val*c.rate),22,true);card.addView(out);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(9);results.addView(card,cp);}}
    Button button(String s,boolean outlined){Button b=new Button(this);b.setText(s);b.setTextColor(outlined?green:Color.WHITE);b.setAllCaps(false);b.setTextSize(16);b.setBackground(bg(outlined?Color.WHITE:green,outlined?green:0));return b;}
    void chooseBase(){String[] labels=new String[currencies.size()];for(int i=0;i<currencies.size();i++){Cur c=currencies.get(i);labels[i]=c.flag+"  "+c.code+"  "+c.name;}new AlertDialog.Builder(this).setTitle("Основная валюта").setItems(labels,(d,w)->{String next=currencies.get(w).code;if(!next.equals(base)){base=next;for(Cur c:currencies)if(!c.code.equals(base))c.rate=0;}save();showMain();showSettings();}).show();}
    void showSettings(){
        ScrollView scroll=new ScrollView(this);LinearLayout body=col();pad(body,20,18,20,20);scroll.addView(body);TextView title=text("Валюты и курсы",24,true);body.addView(title);TextView note=text("Курсы указаны относительно основной валюты: "+base,14,false);note.setTextColor(green);note.setBackground(bg(0xffe4f2e9,0));pad(note,14,12,14,12);LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,-2);nlp.topMargin=dp(14);body.addView(note,nlp);
        for(Cur c:currencies){LinearLayout r=row();pad(r,4,14,4,14);View f=flagView(c.country,c.flag);r.addView(f);TextView name=text(c.code+(c.code.equals(base)?"  • основная":""),17,true);LinearLayout.LayoutParams n=new LinearLayout.LayoutParams(0,-2,1);n.leftMargin=dp(12);r.addView(name,n);if(!c.code.equals(base)){TextView eq=text("1 "+base+" =",13,false);r.addView(eq);EditText rate=new EditText(this);rate.setSingleLine(true);rate.setTextSize(16);rate.setInputType(8194);rate.setEms(6);rate.setText(c.rate==0?"":fmt.format(c.rate));rate.setHint("курс");rate.setSelectAllOnFocus(true);r.addView(rate);rate.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){try{c.rate=Double.parseDouble(s.toString().replace(',','.'));save();}catch(Exception e){c.rate=0;}}public void afterTextChanged(android.text.Editable e){}});}body.addView(r);View line=new View(this);line.setBackgroundColor(0xffe7e9e8);body.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
        Button add=button("＋  Добавить валюту",true);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(18);body.addView(add,ap);add.setEnabled(currencies.size()<6);add.setOnClickListener(v->showAdd());TextView count=text("Используется: "+currencies.size()+" из 6 валют",14,false);count.setGravity(Gravity.CENTER);count.setTextColor(muted);LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2);clp.topMargin=dp(12);body.addView(count,clp);
        new AlertDialog.Builder(this).setView(scroll).setPositiveButton("Готово",(d,w)->{save();showMain();}).setNegativeButton("Отмена",(d,w)->showMain()).show();
    }
    static class Choice {String code,name,flag,country;Choice(String c,String n,String f,String cc){code=c;name=n;flag=f;country=cc;}}
    void showAdd(){ArrayList<Choice> all=new ArrayList<>();all.add(new Choice("EGP","Египетский фунт","🇪🇬","eg"));all.add(new Choice("GBP","Фунт стерлингов","🇬🇧","gb"));all.add(new Choice("TRY","Турецкая лира","🇹🇷","tr"));all.add(new Choice("AED","Дирхам ОАЭ","🇦🇪","ae"));all.add(new Choice("CNY","Китайский юань","🇨🇳","cn"));all.add(new Choice("JPY","Японская иена","🇯🇵","jp"));all.add(new Choice("CHF","Швейцарский франк","🇨🇭","ch"));all.add(new Choice("CAD","Канадский доллар","🇨🇦","ca"));all.add(new Choice("AUD","Австралийский доллар","🇦🇺","au"));all.add(new Choice("INR","Индийская рупия","🇮🇳","in"));ArrayList<Choice> available=new ArrayList<>();for(Choice x:all)if(find(x.code)==null)available.add(x);String[] labels=new String[available.size()];for(int i=0;i<labels.length;i++)labels[i]=available.get(i).flag+"  "+available.get(i).code+" — "+available.get(i).name;new AlertDialog.Builder(this).setTitle("Добавить валюту").setItems(labels,(d,w)->{Choice x=available.get(w);EditText rate=new EditText(this);rate.setSingleLine(true);rate.setInputType(8194);rate.setHint("Курс относительно "+base);new AlertDialog.Builder(this).setTitle(x.flag+"  "+x.code).setMessage("Введите курс: 1 "+base+" = ? "+x.code).setView(rate).setNegativeButton("Отмена",null).setPositiveButton("Добавить",(dd,ww)->{double v=0;try{v=Double.parseDouble(rate.getText().toString().replace(',','.'));}catch(Exception ignored){}currencies.add(new Cur(x.code,x.name,x.flag,x.country,v));save();showSettings();downloadFlag(x.country);}).show();}).setNegativeButton("Отмена",null).show();}
    void downloadFlag(String country){new Thread(()->{try{URL u=new URL("https://raw.githubusercontent.com/lipis/flag-icons/main/flags/4x3/"+country+".svg");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(8000);InputStream in=c.getInputStream();File f=new File(getFilesDir(),"flag-"+country+".svg");FileOutputStream out=new FileOutputStream(f);byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);out.close();in.close();c.disconnect();}catch(Exception ignored){} }).start();}
}
